# Online Pharmacy Application

Name: Dipesh Dahal

CollegeID: 130727

Batch: Jan19A

## List of Main Features

Login/Register

Admin:
Add/ update Medicines
View Orders
Process Orders

User:
Search Medicines
Order Medicine
Cancel Order
Upload Prescription

# Frontend code architecture

Front End is developed with react and redux. the app is inside medapp folder.
cd medapp
port=9001 npm start

The app runs on port 9002 and sends api request on port 3003. Here redux is used to handle states of app which works through reducers. Action folder includes any action needed to perfom. components includes views and some logics, reducers handle the states and utils sets JWT token .
Bootstrap is used for responsive UI Design.

#Dependencies
axios
bootstrap
moment
react
react-bootstrap
react-dom
react-moment
react-redux
react-router-dom
react-scripts
redux
redux-devtools-extension
redux-thunk
uuid
