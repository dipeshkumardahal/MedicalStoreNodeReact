import React, { Fragment, useState } from 'react';
import { Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { addMedicine } from '../../actions/medicine';

const AddMedicine = ({ addMedicine, isAuthenticated }) => {
  const [formData, setFormData] = useState({
    name: '',
    mg: '',
    price: '',
    type: '',
    desc: '',
    available_quantity: ''
  });

  const { name, mg, price, type, desc, available_quantity } = formData;

  const onChange = e => {
    console.log(e.target.name, e.target.value);
    setFormData({ ...formData, [e.target.name]: e.target.value });
    console.log(formData);
  };
  const onSubmit = async e => {
    e.preventDefault();
    addMedicine({ name, mg, price, type, desc, available_quantity });
  };

  if (!isAuthenticated) {
    return <Redirect to='/login' />;
  }
  return (
    <Fragment>
      <div className='login-page white-bg'>
        <h1>Add Medicine</h1>
        <div className='row'>
          <div className='col'>
            <form className='form' onSubmit={e => onSubmit(e)}>
              <div className='form-group'>
                <label htmlFor='medicine-name'>Name</label>
                <input
                  type='text'
                  className='form-control'
                  name='name'
                  placeholder='Enter name of the medicine'
                  value={name}
                  id='medicine-name'
                  onChange={e => onChange(e)}
                  required
                />
              </div>

              <div className='form-group'>
                <label htmlFor='medicine-mg'>Mg</label>
                <input
                  type='text'
                  className='form-control'
                  id='medicine-mg'
                  placeholder='Enter mg'
                  name='mg'
                  value={mg}
                  onChange={e => onChange(e)}
                  required
                />
              </div>

              <div className='form-group'>
                <label htmlFor='medicine-type'>Type</label>
                <input
                  type='text'
                  className='form-control'
                  id='medicine-type'
                  placeholder='Enter type'
                  name='type'
                  value={type}
                  onChange={e => onChange(e)}
                  required
                />
              </div>
              <div className='form-group'>
                <label htmlFor='medicine-price'>Price</label>
                <input
                  type='number'
                  className='form-control'
                  id='medicine-price'
                  placeholder='Enter price'
                  name='price'
                  value={price}
                  onChange={e => onChange(e)}
                  required
                />
              </div>

              <div className='form-group'>
                <label htmlFor='medicine-desc'>Description</label>
                <textarea
                  name='desc'
                  id='medicine-desc'
                  className='form-control'
                  value={desc}
                  onChange={e => onChange(e)}
                  required
                />
              </div>

              <div className='form-group'>
                <label htmlFor='medicine-available_quantity'>
                  Available Quantity
                </label>
                <input
                  type='number'
                  className='form-control'
                  id='medicine-available_quantity'
                  name='available_quantity'
                  onChange={e => onChange(e)}
                  value={available_quantity}
                  required
                />
              </div>

              <button type='submit' className='btn btn-primary'>
                Add a medicine
              </button>
            </form>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

AddMedicine.propTypes = {
  addMedicine: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool
};
const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated
});
export default connect(
  mapStateToProps,
  { addMedicine }
)(AddMedicine);
