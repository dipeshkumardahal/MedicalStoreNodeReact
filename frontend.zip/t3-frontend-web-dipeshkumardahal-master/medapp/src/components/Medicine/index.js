import React from 'react';
import { connect } from 'react-redux';
import { Table } from 'react-bootstrap';
import { loadAllMedicines } from '../../actions/medicine';
import { addOrder } from '../../actions/order';
import Modal from '../Modal';
class Medicine extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      quantity: 1,
      show: false
    };
  }

  onAddOrder(medicine) {
    const { _id: id } = medicine;
    const { user } = this.props;

    var orderObject = {
      medicine_id: id,
      user_id: user._id,
      quantity: this.state.quantity,
      price: this.state.quantity * medicine.price
    };

    this.props.addOrder(orderObject);
  }

  quantityUpdate(e) {
    this.setState({
      quantity: e
    });
  }

  closeModal(medicine) {
    this.onAddOrder(medicine);
  }

  componentDidMount() {
    this.props.loadAllMedicines();
  }
  render() {
    const { medicines, user } = this.props;
    if (medicines) {
      // props.loadAllMedicines();
    }
    console.log(this.state.show);
    return (
      <div>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Type</th>
              <th>mg</th>
              <th>Description</th>
              <th>Price</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {medicines.map((value, index) => {
              return (
                <tr key={index}>
                  <td>{index}</td>
                  <td>{value.name}</td>
                  <td>{value.type}</td>
                  <td>{value.mg}</td>
                  <td>{value.desc}</td>
                  <td>{value.price}</td>
                  <th>
                    <Modal
                      onSubmit={e => {
                        this.closeModal(value);
                        console.log('CLOSED', e);
                      }}
                      quantityChanged={e => this.quantityUpdate(e)}
                    />
                  </th>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </div>
    );
  }
}

Medicine.propTypes = {};

const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated,
  user: state.auth.user,
  medicines: state.medicine.all
});
export default connect(
  mapStateToProps,
  { loadAllMedicines, addOrder }
)(Medicine);
