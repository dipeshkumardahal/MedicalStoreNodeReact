import React from 'react';
import { connect } from 'react-redux';
import { Table } from 'react-bootstrap';
import { loadAllMedicines } from '../../actions/medicine';

const MedicineDetails = props => {
  //   props.navigation.
  props.loadAllMedicines();
  const { medicines } = props;
  return (
    <div>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>mg</th>
            <th>Description</th>
            <th>type</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {medicines.map((value, index) => {
            return (
              <tr>
                <td>{index}</td>
                <td>{value.name}</td>
                <td>{value.mg}</td>
                <td>{value.desc}</td>
                <td>{value.type}</td>
                <td>{value.price}</td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

MedicineDetails.propTypes = {};

const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated,
  medicines: state.medicine.all
});
export default connect(
  mapStateToProps,
  { loadAllMedicines }
)(MedicineDetails);
