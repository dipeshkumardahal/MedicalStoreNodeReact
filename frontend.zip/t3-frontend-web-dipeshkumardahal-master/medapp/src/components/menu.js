import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { logout } from '../actions/auth';

const Menu = ({ auth: { isAuthenticated, loading }, logout }) => {
  const authLinks = (
    <ul className='navbar-nav mr-auto'>
      {/*<li className='nav-item'>
        <Link to='/upload' className='nav-link'>
          <i className='fas fa-user' />{' '}
          <span className='hide-sm success'>Upload Prescription</span>
        </Link>
  </li>*/}
      <li className='nav-item'>
        <Link to='/medicine/create' className='nav-link'>
          <i className='fas fa-user' />{' '}
          <span className='hide-sm success'>Add Medicine</span>
        </Link>
      </li>

      <li className='nav-item'>
        <Link to='/mymeds' className='nav-link'>
          <i className='fas fa-user' />{' '}
          <span className='hide-sm'>Medicines</span>
        </Link>
      </li>
      <li className='nav-item'>
        <Link to='/myorders' className='nav-link'>
          <i className='fas fa-user' /> <span className='hide-sm'>Orders</span>
        </Link>
      </li>
      <li>
        <Link onClick={logout} to='#!' className='nav-link'>
          <i className='fas fa-sign-out-alt' />{' '}
          <span className='hide-sm'>Logout</span>
        </Link>
      </li>
    </ul>
  );

  const guestLinks = (
    <ul className='navbar-nav mr-auto'>
      <li>
        <Link to='/login' className='nav-link'>
          Login
        </Link>
      </li>
      <li className='nav-item'>
        <Link to='/register' className='nav-link'>
          Register
        </Link>
      </li>
    </ul>
  );

  return (
    <nav className='navbar navbar-expand-lg navbar-light bg-light'>
      <Link className='navbar-brand' to='./'>
        Online Pharmacy APP
      </Link>
      <button
        className='navbar-toggler'
        type='button'
        data-toggle='collapse'
        data-target='#navbarSupportedContent'
        aria-controls='navbarSupportedContent'
        aria-expanded='false'
        aria-label='Toggle navigation'
      >
        <span className='navbar-toggler-icon' />
      </button>

      <div className='collapse navbar-collapse' id='navbarSupportedContent'>
        {/*
        <form className='form-inline my-2 my-lg-0'>
          <input
            className='form-control mr-sm-2'
            type='search'
            placeholder='Search'
            aria-label='Search'
          />
          <button
            className='btn btn-outline-success my-2 my-sm-0'
            type='submit'
          >
            Search
          </button>
        </form>
        */}
      </div>

      {!loading && (
        <Fragment>{isAuthenticated ? authLinks : guestLinks}</Fragment>
      )}
    </nav>
  );
};

Menu.propTypes = {
  logout: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth
});

export default connect(
  mapStateToProps,
  { logout }
)(Menu);
