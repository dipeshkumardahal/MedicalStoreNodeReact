import React, { Fragment, useState } from 'react';
import { connect } from 'react-redux';
import { setAlert } from '../actions/alert';
import { register } from '../actions/auth';
import PropTypes from 'prop-types';
import { Link, Redirect } from 'react-router-dom';

const Register = ({ setAlert, register, isAuthenticated }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    age: '',
    password: '',
    passwordconfirm: ''
  });
  const {
    name,
    phone,
    email,
    address,
    age,
    password,
    passwordconfirm
  } = formData;
  const onChange = e =>
    setFormData({ ...formData, [e.target.name]: e.target.value });
  const onSubmit = async e => {
    e.preventDefault();
    if (password !== passwordconfirm) {
      setAlert('password dont match', 'danger');
    } else {
      register({ name, phone, email, address, age, password });
    }
  };

  if (isAuthenticated) {
    return <Redirect to='/dashboard' />;
  }
  return (
    <Fragment>
      <div className='login-page'>
        <h1>Create Your Account</h1>
        <div className='row'>
          <div className='col'>
            <form className='form' onSubmit={e => onSubmit(e)}>
              <div className='form-group'>
                <label htmlFor='registerNameInput'>Full Name</label>
                <input
                  type='text'
                  className='form-control'
                  id='registerNameInput'
                  placeholder='Enter Your Name'
                  name='name'
                  value={name}
                  onChange={e => onChange(e)}
                  required
                />
              </div>
              <div className='form-group'>
                <label htmlFor='registerPhoneInput'>Phone</label>
                <input
                  type='tel'
                  className='form-control'
                  id='registerPhoneInput'
                  placeholder='Enter Your Phone Number'
                  name='phone'
                  value={phone}
                  onChange={e => onChange(e)}
                  required
                />

                <div className='form-group'>
                  <label htmlFor='registerAddressInput'>Address</label>
                  <input
                    type='text'
                    className='form-control'
                    id='registerAddressInput'
                    placeholder='Enter Your Address'
                    name='address'
                    value={address}
                    onChange={e => onChange(e)}
                    required
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor='registerEmailInput'>Email</label>
                  <input
                    type='email'
                    className='form-control'
                    id='registerEmailInput'
                    placeholder='Enter Your email address'
                    name='email'
                    value={email}
                    onChange={e => onChange(e)}
                    required
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor='registerAgeInput'>Age</label>
                  <input
                    type='text'
                    className='form-control'
                    id='registerAgeInput'
                    placeholder='Enter Your Age'
                    name='age'
                    value={age}
                    onChange={e => onChange(e)}
                    required
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor='registerPasswordInput'>Password</label>
                  <input
                    type='password'
                    className='form-control'
                    id='registerPasswordInput'
                    placeholder='Enter Your Password'
                    name='password'
                    value={password}
                    onChange={e => onChange(e)}
                    required
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor='registerPasswordInput2'>
                    Password Confirm
                  </label>
                  <input
                    type='password'
                    className='form-control'
                    id='registerPasswordInput2'
                    placeholder='Enter Your Password Agian'
                    name='passwordconfirm'
                    value={passwordconfirm}
                    onChange={e => onChange(e)}
                    required
                  />
                </div>
                <button type='submit' className='btn btn-primary'>
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

Register.propTypes = {
  setAlert: PropTypes.func.isRequired,
  register: PropTypes.func.isRequired
};

export default connect(
  null,
  { setAlert, register }
)(Register);
