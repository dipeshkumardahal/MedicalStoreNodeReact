import React from 'react';
import { Link } from 'react-router-dom';
const Landing = () => {
  return (
    <div className='App'>
      <div className='App-header'>
        <div className='App-logo'>
          <h1>My Pharma</h1>
        </div>
        Welcome To Online Pharmacy application.
        <br />
        <Link to='./register'>
          <br />
          <button type='button' className='btn'>
            New User ?
          </button>
        </Link>
      </div>
    </div>
  );
};

export default Landing;
