import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = props => {
  return (
    <div>
      <div className='box'>
        <Link to='/mymeds'>My Medicines</Link>
      </div>

      <div className='box'>
        <Link to='/medicine/create'>Add</Link>
      </div>
    </div>
  );
};

Dashboard.propTypes = {};

export default Dashboard;
