import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Table } from 'react-bootstrap';
import {
  loadMyOrders,
  changeOrderStatus,
  loadAllOrders
} from '../../actions/order';
import { loadAllMedicines, loadMyMedicines } from '../../actions/medicine';

class Orders extends React.Component {
  componentDidMount() {
    if (this.props.medicines.length < 1) {
      this.props.loadAllMedicines();
    }
    this.props.loadMyOrders();
  }

  onChangeStatus(id, status) {
    this.props.changeOrderStatus({ id, status });
  }

  generateMedicineName(id) {
    var test = this.props.medicines.filter((value, index) => {
      return value._id == id;
    });

    if (test.length) {
      return test[0].name;
    }
    return id;
  }
  render() {
    var { orders, medicines, user } = this.props;
    return (
      <div>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Quantity</th>
              <th>Current Status</th>
              <th>Price</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((value, index) => {
              return (
                <tr key={index}>
                  <td>{index}</td>
                  <td>{this.generateMedicineName(value.medicine_id)}</td>
                  <td>{value.quantity}</td>
                  <td>{value.status}</td>
                  <td>{value.price}</td>
                  <td>
                    {user && user.admin ? (
                      <Fragment>
                        <button
                          className='btn btn-primary'
                          disabled={value.status == 'queued' ? true : false}
                          onClick={e =>
                            this.onChangeStatus(value._id, 'queued')
                          }
                        >
                          Queue
                        </button>
                        <button
                          className='btn btn-primary'
                          onClick={e =>
                            this.onChangeStatus(value._id, 'process')
                          }
                          disabled={value.status == 'process' ? true : false}
                        >
                          Process
                        </button>
                        <button
                          className='btn btn-primary'
                          onClick={e =>
                            this.onChangeStatus(value._id, 'complete')
                          }
                          disabled={value.status == 'complete? true: false'}
                        >
                          Complete
                        </button>
                        <button
                          className='btn btn-danger'
                          onClick={e =>
                            this.onChangeStatus(value._id, 'cancel')
                          }
                          disabled={value.status == 'cancel' ? true : false}
                        >
                          Cancel
                        </button>
                      </Fragment>
                    ) : (
                      <Fragment>
                        {value.status === 'queued' ? (
                          <button>Cancel</button>
                        ) : null}
                      </Fragment>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </div>
    );
  }
}

Orders.propTypes = {};
const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated,
  user: state.auth.user,
  medicines: state.medicine.all,
  orders: state.order.all
});

export default connect(
  mapStateToProps,
  { loadMyOrders, loadAllMedicines, loadMyMedicines, changeOrderStatus }
)(Orders);
