import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';

function Example(props) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button variant='primary' onClick={e => handleShow()}>
        Add Order
      </Button>

      <Modal show={show} className={show ? 'show' : null} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Input Quanity</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input
            type='number'
            onChange={e => props.quantityChanged(e.target.value)}
            placeholder='Input quantity'
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={handleClose}>
            Cancel
          </Button>
          <Button
            variant='primary'
            onClick={e => {
              props.onSubmit();
              handleClose();
            }}
          >
            Confirm Order
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default Example;
