import React, { Fragment, useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
import Login from './components/login';
import Menu from './components/menu';
import Register from './components/Register';
import Alert from './components/Alert';
import Dashboard from './components/dashboard';
import ListMedicine from './components/Medicine/index';
import AddMedicine from './components/Medicine/create';
import MyOrders from './components/Orders/index';
import { loadUser } from './actions/auth';
import { setAlert } from './actions/alert';
import Landing from './components/landing';

import { Provider } from 'react-redux';
import store from './store';
import setAuthToken from './utils/setAuthToken';

if (localStorage.token) {
  setAuthToken(localStorage.token);
}

const App = () => {
  useEffect(() => {
    store.dispatch(loadUser());
    // store.dispatch(setAlert('test', 'success', 50000));
  }, []);
  return (
    <Provider store={store}>
      <Router>
        <Fragment>
          <Menu />
          <Route exact path='/' component={Landing} />
          <section className='container'>
            <Alert />
            <Route exact path='/register' component={Register} />
            <Route exact path='/login' component={Login} />
            <Route exact path='/dashboard' component={Dashboard} />
            <Route exact path='/mymeds' component={ListMedicine} />

            <Route exact path='/myorders' component={MyOrders} />

            <Route exact path='/medicine/create' component={AddMedicine} />
          </section>
        </Fragment>
      </Router>
    </Provider>
  );
};

export default App;
