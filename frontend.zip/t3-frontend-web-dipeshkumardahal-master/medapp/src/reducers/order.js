import {
  FETCH_ORDERS_SUCCESS,
  FETCH_ORDERS_FAIL,
  FETCH_MY_ORDERS_SUCCESS,
  FETCH_MY_ORDERS_FAIL,
  CHANGE_ORDER_STATUS_SUCCESS,
  CHANGE_ORDER_STATUS_FAIL
} from '../actions/types';

const initialState = {
  all: [],
  loading: true,
  filteredData: []
};

export default function(state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case FETCH_ORDERS_SUCCESS:
      // var data = [];
      // if (Array.isArray(payload)) {
      //   data = payload.map((value, index) => {
      //     return {
      //       ...value
      //     };
      //   });
      // }

      return {
        ...state,
        loading: false,
        all: payload
      };
    case CHANGE_ORDER_STATUS_SUCCESS:
      let position = null;
      var datas = state.all.slice();
      datas.filter((order, index) => {
        if (order._id == payload._id) {
          position = index;
          return true;
        }
        return false;
      });

      if (datas[position]) {
        datas[position] = payload;
      }
      return {
        ...state,
        all: datas
      };
    case FETCH_MY_ORDERS_SUCCESS:
      return {
        ...state,
        loading: false,
        all: payload
      };
    case FETCH_MY_ORDERS_FAIL:
      return {
        ...state,
        loading: true
      };
    case CHANGE_ORDER_STATUS_FAIL:
      return { ...state };
    case FETCH_ORDERS_FAIL:
      return {
        ...state,
        loading: true
      };

    default:
      return state;
  }
}
