import {
  FETCH_MEDICINES_SUCCESS,
  FETCH_MEDICINES_FAIL
} from '../actions/types';

const initialState = {
  all: [],
  loading: true
};

export default function(state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case FETCH_MEDICINES_SUCCESS:
      return {
        ...state,
        loading: false,
        all: payload
      };
    case FETCH_MEDICINES_FAIL:
      return {
        ...state,
        loading: true
      };

    default:
      return state;
  }
}
