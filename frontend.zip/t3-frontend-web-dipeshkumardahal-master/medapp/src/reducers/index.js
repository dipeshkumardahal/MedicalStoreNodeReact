import { combineReducers } from 'redux';
import alert from './alert';
import auth from './auth';
import medicine from './medicine';
import order from './order';

export default combineReducers({
  alert,
  auth,
  medicine,
  order
});
