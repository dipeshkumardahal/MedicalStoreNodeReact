import axios from 'axios';

import {
  FETCH_MEDICINES_SUCCESS,
  FETCH_MY_MEDICINES_SUCCESS,
  FETCH_MY_MEDICINES_FAIL,
  FETCH_MEDICINES_FAIL,
  ADD_MEDICINE_SUCCESS,
  ADD_MEDICINE_FAIL
} from './types';
import setAuthToken from '../utils/setAuthToken';

const BASE_URL = 'http://localhost:3003';

// Load User
export const loadMyMedicines = () => async dispatch => {
  if (localStorage.token) {
    setAuthToken(localStorage.token);
  }

  try {
    const res = await axios.get(BASE_URL + '/my-medicines');

    dispatch({
      type: FETCH_MY_MEDICINES_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    dispatch({
      type: FETCH_MY_MEDICINES_FAIL
    });
  }
};

// Logout / Clear Profile
export const loadAllMedicines = () => async dispatch => {
  if (localStorage.token) {
    setAuthToken(localStorage.token);
  }

  try {
    const res = await axios.get(BASE_URL + '/medicines');

    dispatch({
      type: FETCH_MEDICINES_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    dispatch({
      type: FETCH_MEDICINES_FAIL
    });
  }
};

export const addMedicine = ({
  name,
  type,
  mg,
  price,
  company,
  desc,
  available_quantity
}) => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  };

  const body = JSON.stringify({
    name,
    type,
    mg,
    price,
    company,
    desc,
    available_quantity
  });

  try {
    const res = await axios.post(BASE_URL + '/medicines', body, config);

    dispatch({
      type: ADD_MEDICINE_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    // const errors = err.response.data.errors;
    console.log('ERRR', err);

    // if (errors) {
    //   errors.forEach(error => dispatch(setAlert(error.msg, 'danger')));
    // }

    dispatch({
      type: ADD_MEDICINE_FAIL
    });
  }
};
