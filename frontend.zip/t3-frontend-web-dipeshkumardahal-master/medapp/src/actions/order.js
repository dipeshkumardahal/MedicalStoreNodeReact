import axios from 'axios';

import {
  FETCH_ORDERS_SUCCESS,
  FETCH_MY_ORDERS_SUCCESS,
  FETCH_MY_ORDERS_FAIL,
  FETCH_ORDERS_FAIL,
  CHANGE_ORDER_STATUS_SUCCESS,
  CHANGE_ORDER_STATUS_FAIL,

  //   ORDERS_LOADED,
  //   GET_ORDER_SUCCESS,
  //   GET_ORDER_FAIL,
  ADD_ORDER_SUCCESS,
  ADD_ORDER_FAIL,
  REMOVE_ORDER_SUCCESS,
  REMOVE_ORDER_FAIL
} from './types';
import setAuthToken from '../utils/setAuthToken';

const BASE_URL = 'http://localhost:3003';

// Load User
export const loadMyOrders = () => async (dispatch, getState) => {
  if (localStorage.token) {
    setAuthToken(localStorage.token);
  }

  try {
    const res = await axios.post(BASE_URL + '/orders/my-orders', {
      user_id: getState().auth.user._id
    });

    dispatch({
      type: FETCH_MY_ORDERS_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    dispatch({
      type: FETCH_MY_ORDERS_FAIL
    });
  }
};

// Logout / Clear Profile
export const loadAllOrders = () => async dispatch => {
  if (localStorage.token) {
    setAuthToken(localStorage.token);
  }

  try {
    const res = await axios.get(BASE_URL + '/orders');

    dispatch({
      type: FETCH_ORDERS_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    dispatch({
      type: FETCH_ORDERS_FAIL
    });
  }
};

export const addOrder = ({
  user_id,
  medicine_id,
  quantity,
  price
}) => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  };

  const body = JSON.stringify({
    user_id,
    medicine_id,
    quantity,
    price
  });

  try {
    const res = await axios.post(BASE_URL + '/orders', body, config);

    dispatch({
      type: ADD_ORDER_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    // const errors = err.response.data.errors;
    console.log('ERRR', err);

    // if (errors) {
    //   errors.forEach(error => dispatch(setAlert(error.msg, 'danger')));
    // }

    dispatch({
      type: ADD_ORDER_FAIL
    });
  }
};

export const removeOrder = ({ id }) => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  };

  try {
    const res = await axios.delete(BASE_URL + '/orders/' + id, config);

    dispatch({
      type: REMOVE_ORDER_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    // const errors = err.response.data.errors;
    console.log('ERRR', err);

    // if (errors) {
    //   errors.forEach(error => dispatch(setAlert(error.msg, 'danger')));
    // }

    dispatch({
      type: REMOVE_ORDER_FAIL
    });
  }
};

export const changeOrderStatus = ({ id, status }) => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  };

  const body = JSON.stringify({
    id,
    status
  });

  try {
    const res = await axios.post(
      BASE_URL + '/orders/' + id + '/status',
      body,
      config
    );

    dispatch({
      type: CHANGE_ORDER_STATUS_SUCCESS,
      payload: res.data
    });
  } catch (err) {
    // const errors = err.response.data.errors;
    console.log('ERRR', err);

    // if (errors) {
    //   errors.forEach(error => dispatch(setAlert(error.msg, 'danger')));
    // }

    dispatch({
      type: CHANGE_ORDER_STATUS_FAIL
    });
  }
};
