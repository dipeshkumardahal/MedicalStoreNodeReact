var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var cors = require('cors');

var corsOptions = {
  origin: 'http://localhost:9001',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
};

const connectDB = require('./config/db');
connectDB();

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var authRouter = require('./routes/auth');
var medicineRouter = require('./routes/medicines');
var orderRouter = require('./routes/order');
var uploadRouter = require('./routes/upload');

var app = express();

//middleware
app.use(logger('dev'));
app.use(express.json({ extended: false }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', cors(corsOptions), indexRouter);
app.use('/users', cors(corsOptions), usersRouter);
app.use('/auth', cors(corsOptions), authRouter);
app.use('/medicines', cors(corsOptions), medicineRouter);
app.use('/orders', cors(corsOptions), orderRouter);
//app.use('/upload', uploadRouter);

//const PORT = process.env.PORT || 5000;
//app.listen(PORT, () => console.log(`server started on ${PORT}`));

module.exports = app;
