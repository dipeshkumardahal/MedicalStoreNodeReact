var mongoose = require('mongoose');
var Schema = mongoose.Schema;

let MedicineSchema = new Schema(
  {
    name: {
      type: String,
      default: true
    },
    type: {
      type: String,
      required: true
    },
    mg: {
      type: String,
      required: true
    },
    price: {
      type: Number,
      required: true
    },
    company: {
      type: String
    },
    desc: {
      type: String,
      required: true
    },
    available_quantity: {
      type: Number
    }
  },
  {
    timestamps: true
  }
);

var Medicines = mongoose.model('Medicine', MedicineSchema);
module.exports = Medicines;
