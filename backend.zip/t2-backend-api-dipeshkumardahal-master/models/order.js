const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'user'
  },
  medicine_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Medicine'
  },
  quantity: {
    type: String
  },
  status: {
    type: String,
    default: 'queued'
  },
  price: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

var Orders = mongoose.model('Order', OrderSchema);
module.exports = Orders;
