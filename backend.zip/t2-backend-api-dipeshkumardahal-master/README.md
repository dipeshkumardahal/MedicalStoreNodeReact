# Online Pharmacy Application

Name: Dipesh Dahal

CollegeID: 130727

Batch: Jan19A

Doctors Portal

## List of Main Features

Login/Register

Admin:
Add Medicines
View Orders
Process Orders

User:
Order Medicine
Cancel Order

## API Documentation

Routes are :
medicines: get/post/update/delete
user: get/post
orders: get/ppost/update/delete
upload: get/post

Run:
PORT=3003 npm start
