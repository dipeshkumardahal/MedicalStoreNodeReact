const express = require('express');
const router = express.Router();
var orders = require('../models/order');
var { check, validationResult } = require('express-validator');
const auth = require('../middleware/auth');

router.get('/', auth, (req, res, next) => {
  orders
    .find({})
    .then(
      orders => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(orders);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.post('/my-orders', auth, (req, res, next) => {
  orders
    .find({ user_id: req.body.user_id })
    .populate({ path: 'Medicine', select: 'name' })
    .then(
      data => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(data);
      },
      err => next(err)
    )
    .catch(err => next(err));
});
router.post('/:id/status', auth, (req, res, next) => {
  orders
    .findByIdAndUpdate({ _id: req.params.id }, { status: req.body.status })
    .then(
      data => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(data);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.get('/:id', auth, (req, res, next) => {
  orders
    .findById(req.params.id)
    .then(
      order => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(order);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.post('/', auth, (req, res, next) => {
  orders
    .create(req.body)
    .then(
      order => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(order);
      },
      err => next(err)
    )
    .catch(err => next(err));
});
router.put('/:id', auth, (req, res, next) => {
  orders
    .findByIdAndUpdate({ _id: req.params.id }, req.body)
    .then(
      order => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(order);
      },
      err => next(err)
    )
    .catch(err => next(err));
});
router.delete('/:id', auth, (req, res, next) => {
  orders
    .findByIdAndRemove({ _id: req.params.id }, req.body)
    .then(
      order => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json('Deleted Sucecess fully');
      },
      err => next(err)
    )
    .catch(err => next(err));
});

module.exports = router;
