var express = require('express');
var router = express.Router();
var { check, validationResult } = require('express-validator');
const User = require('../models/User');
const gravatar = require('gravatar');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('config');

/* GET users listing. */
router.get('/', (req, res) => {
  res.send('users route');
});

/* Post users */
router.post(
  '/',
  [
    check('name', 'Name is Required')
      .not()
      .isEmpty(),
    check('email', 'enter valid email').isEmail(),
    check('phone', 'Enter a valid phone number').isLength({ min: 9 }),
    check('password', 'password must be min 6 caracter long').isLength({
      min: 6
    }),
    check('age', 'Age is Required')
      .not() 
      .isEmpty()
  ],
  async (req, res) => {
    console.log(req.body);
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { name, phone, email, age, password } = req.body;

    try {
      let user = await User.findOne({ phone });
      if (user) {
        return res
          .status(400)
          .json({ errors: [{ msg: 'User already exists' }] });
      }

      user = new User({
        name,
        phone,
        email,
        age,
        password
      });

      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);

      user.save();

      const payload = {
        user: {
          id: user.id
        }
      };
      jwt.sign(payload, config.get('jwtSecret'), (err, token) => {
        if (err) throw err;
        res.json({ token });
      });
    } catch (err) {
      console.error(err.message);
      res.status(500).send('server error');
    }
  }
);

module.exports = router;
