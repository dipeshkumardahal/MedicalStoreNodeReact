const express = require('express');
const auth = require('../middleware/auth');
const router = express.Router();
const medicines = require('../models/medicines');

router.get('/', auth, (req, res, next) => {
  medicines
    .find({})
    .then(
      medicines => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(medicines);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.get('/:id', auth, (req, res, next) => {
  medicines
    .findById(req.params.id)
    .then(
      medicine => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(medicine);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.post('/', auth, (req, res, next) => {
  medicines
    .create(req.body)
    .then(
      medicine => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(medicine);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.post('/my-medicine', auth, (req, res, next) => {
  medicines
    .create(req.body)
    .then(
      medicine => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(medicine);
      },
      err => next(err)
    )
    .catch(err => next(err));
});

router.put('/:id', auth, (req, res, next) => {
  medicines
    .findByIdAndUpdate({ _id: req.params.id }, req.body)
    .then(
      medicine => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(medicine);
      },
      err => next(err)
    )
    .catch(err => next(err));
});
router.delete('/:id', auth, (req, res, next) => {
  medicines
    .findByIdAndRemove({ _id: req.params.id }, req.body)
    .then(
      medicine => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json('Deleted Sucecess fully');
      },
      err => next(err)
    )
    .catch(err => next(err));
});

module.exports = router;
